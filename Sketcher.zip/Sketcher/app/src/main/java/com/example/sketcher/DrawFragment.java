package com.example.sketcher;

import androidx.fragment.app.Fragment;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;


public class DrawFragment extends Fragment {

    private View inflatedView = null;
    private Activity containerActivity = null;
    private DrawingView dv = null;

    public void setContainerActivity(Activity containerActivity) {
        System.out.println("set");
        this.containerActivity = containerActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        inflatedView = inflater.inflate(R.layout.fragment_draw, container, false);
        return inflatedView;
    }

    @Override
    public void onViewCreated(View view,  Bundle savedInstanceState) {
        dv = new DrawingView(containerActivity, null);
        LinearLayout ll = (LinearLayout)getView().findViewById(R.id.drawing);
        Button b = containerActivity.findViewById(R.id.blue);
        if(b == null)
            System.out.println("null1");
        if(ll == null)
            System.out.println("null2");
        ll.addView(dv);
        System.out.println("create");
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);

    }


    public void clearDrawing() {
        dv.startNew();
    }

    public void changeColor(int v){
        dv.changeColor(v);
    }

    public void changeSize(int v){
        dv.changeSize(v);
    }

    public Bitmap getBM(){
        return dv.getBitmap();
    }

    public void recover(Bitmap bm){
        dv.recover(bm);
    }

}
