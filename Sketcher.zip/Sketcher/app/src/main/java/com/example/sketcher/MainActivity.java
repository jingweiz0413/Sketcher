package com.example.sketcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentTransaction;
import android.view.View;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import java.io.File;
import java.util.Date;
import android.os.Environment;
import java.text.SimpleDateFormat;
import java.io.FileOutputStream;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.widget.TextView;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {


    private DrawFragment dv;
    private String currentPhotoPath;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        draw();
    }


    public void clearDrawing(View v) {
        dv.clearDrawing();
    }

    public void chooseColor(View v){
        if(dv == null)
            System.out.println("null!!");
        dv.changeColor(0x3);
        System.out.println("goodd......"+R.id.red+" "+v.getId());
        if(v.getId() == R.id.red)
            dv.changeColor(0xFFED1313);
        else if(v.getId() == R.id.green)
            dv.changeColor(0xFF09E635);
        else if(v.getId() == R.id.blue)
            dv.changeColor(0xFF3225E6);
        else if(v.getId() == R.id.purple)
            dv.changeColor(0xFF8E07A6);

    }

    public void chooseSize(View v){
        Button b = (Button) findViewById(v.getId());
        String str = b.getText().toString();
        int s = 15;
        if(str.equals("M"))
            s = 25;
        else if(str.equals("L"))
            s = 35;
        else
            s = 15;
        dv.changeSize(s);

    }

    public void showContacts(View v) {
        ContactsFragment cf = new ContactsFragment();
        cf.setContainerActivity(this);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.outer, cf);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void draw() {
        dv = new DrawFragment();
        dv.setContainerActivity(this);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.outer, dv);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void infoClick(View v) throws Exception{
        String text = ((TextView)v).getText().toString();
        String id = text.substring(text.indexOf(" :: ")+4);
        String name = text.substring(0,text.indexOf(" :: "));
        System.out.println("a"+id+"a");
        String email = "";
        Cursor emails = getContentResolver().query(
                ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = " + id, null, null);
        if(emails.moveToNext())
            email = emails.getString(emails.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS));
        emails.close();
        System.out.println("EM: "+email+ ":"+name);


        Uri uri;
        File photoFile = createImageFile();
        uri = FileProvider.getUriForFile(this, "com.example.sketcher.fileprovider", photoFile);
        bitmap = dv.getBM();

        FileOutputStream fOut = new FileOutputStream(photoFile);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);

        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[] { email });
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setType("image/png");
        startActivity(intent);


    }

    private File createImageFile() throws Exception {
        String timeStamp = new
                SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir =
                getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName, ".jpg", storageDir);
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }
}
